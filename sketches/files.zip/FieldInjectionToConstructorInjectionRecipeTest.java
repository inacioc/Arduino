package com.example.rewrite;

import org.junit.jupiter.api.Test;
import org.openrewrite.test.RecipeSpec;
import org.openrewrite.test.RewriteTest;

import static org.openrewrite.java.Assertions.java;

/**
 * Unit tests for {@link FieldInjectionToConstructorInjectionRecipe}.
 *
 * Uses the OpenRewrite test framework (RewriteTest) which compares
 * the "before" source with the expected "after" source after recipe execution.
 */
class FieldInjectionToConstructorInjectionRecipeTest implements RewriteTest {

    @Override
    public void defaults(RecipeSpec spec) {
        spec.recipe(new FieldInjectionToConstructorInjectionRecipe());
    }

    // -------------------------------------------------------------------------
    // TEST 1 — Single @Autowired field
    // -------------------------------------------------------------------------
    @Test
    void singleAutowiredField() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Service;

                @Service
                public class MyService {

                    @Autowired
                    private MyRepository myRepository;
                }
                """,
                """
                import org.springframework.stereotype.Service;

                @Service
                public class MyService {

                    private final MyRepository myRepository;

                    public MyService(MyRepository myRepository) {
                        this.myRepository = myRepository;
                    }
                }
                """
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 2 — Multiple @Autowired fields
    // -------------------------------------------------------------------------
    @Test
    void multipleAutowiredFields() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Service;

                @Service
                public class OrderService {

                    @Autowired
                    private OrderRepository orderRepository;

                    @Autowired
                    private PaymentService paymentService;

                    @Autowired
                    private NotificationService notificationService;
                }
                """,
                """
                import org.springframework.stereotype.Service;

                @Service
                public class OrderService {

                    private final OrderRepository orderRepository;
                    private final PaymentService paymentService;
                    private final NotificationService notificationService;

                    public OrderService(OrderRepository orderRepository,
                                        PaymentService paymentService,
                                        NotificationService notificationService) {
                        this.orderRepository = orderRepository;
                        this.paymentService = paymentService;
                        this.notificationService = notificationService;
                    }
                }
                """
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 3 — Class with no @Autowired fields — should NOT be changed
    // -------------------------------------------------------------------------
    @Test
    void noAutowiredFields_shouldNotChange() {
        rewriteRun(
            java(
                """
                import org.springframework.stereotype.Service;

                @Service
                public class PureService {

                    private String name;

                    public String getName() {
                        return name;
                    }
                }
                """
                // No second argument = no change expected
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 4 — Class already has a parameterized constructor — should NOT be changed
    // -------------------------------------------------------------------------
    @Test
    void existingParameterizedConstructor_shouldNotChange() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Service;

                @Service
                public class AlreadyMigratedService {

                    @Autowired
                    private MyRepository myRepository;

                    public AlreadyMigratedService(MyRepository myRepository) {
                        this.myRepository = myRepository;
                    }
                }
                """
                // No second argument = no change expected
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 5 — Mix of @Autowired and non-@Autowired fields
    //           Only @Autowired ones move to constructor; others stay as-is
    // -------------------------------------------------------------------------
    @Test
    void mixedFields_onlyAutowiredMigratedToConstructor() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Component;

                @Component
                public class ReportComponent {

                    @Autowired
                    private ReportRepository reportRepository;

                    private String reportTitle = "Default";

                    private int pageSize = 10;
                }
                """,
                """
                import org.springframework.stereotype.Component;

                @Component
                public class ReportComponent {

                    private final ReportRepository reportRepository;

                    private String reportTitle = "Default";

                    private int pageSize = 10;

                    public ReportComponent(ReportRepository reportRepository) {
                        this.reportRepository = reportRepository;
                    }
                }
                """
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 6 — @Autowired on a @RestController
    // -------------------------------------------------------------------------
    @Test
    void autowiredInRestController() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.web.bind.annotation.RestController;

                @RestController
                public class UserController {

                    @Autowired
                    private UserService userService;

                    @Autowired
                    private UserMapper userMapper;
                }
                """,
                """
                import org.springframework.web.bind.annotation.RestController;

                @RestController
                public class UserController {

                    private final UserService userService;
                    private final UserMapper userMapper;

                    public UserController(UserService userService, UserMapper userMapper) {
                        this.userService = userService;
                        this.userMapper = userMapper;
                    }
                }
                """
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 7 — @Autowired import is removed when no longer used
    // -------------------------------------------------------------------------
    @Test
    void autowiredImportIsRemoved() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Service;

                @Service
                public class CleanService {

                    @Autowired
                    private CleanRepository cleanRepository;
                }
                """,
                """
                import org.springframework.stereotype.Service;

                @Service
                public class CleanService {

                    private final CleanRepository cleanRepository;

                    public CleanService(CleanRepository cleanRepository) {
                        this.cleanRepository = cleanRepository;
                    }
                }
                """
            )
        );
    }

    // -------------------------------------------------------------------------
    // TEST 8 — Class with only a no-arg constructor should still be migrated
    // -------------------------------------------------------------------------
    @Test
    void classWithNoArgConstructor_shouldMigrate() {
        rewriteRun(
            java(
                """
                import org.springframework.beans.factory.annotation.Autowired;
                import org.springframework.stereotype.Service;

                @Service
                public class LegacyService {

                    @Autowired
                    private LegacyRepository legacyRepository;

                    public LegacyService() {
                        // default constructor
                    }
                }
                """,
                """
                import org.springframework.stereotype.Service;

                @Service
                public class LegacyService {

                    private final LegacyRepository legacyRepository;

                    public LegacyService() {
                        // default constructor
                    }

                    public LegacyService(LegacyRepository legacyRepository) {
                        this.legacyRepository = legacyRepository;
                    }
                }
                """
            )
        );
    }
}
