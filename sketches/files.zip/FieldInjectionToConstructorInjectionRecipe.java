package com.example.rewrite;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.EqualsAndHashCode;
import lombok.Value;
import org.openrewrite.*;
import org.openrewrite.internal.ListUtils;
import org.openrewrite.java.*;
import org.openrewrite.java.tree.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * OpenRewrite recipe that converts @Autowired field injection to constructor injection.
 *
 * Before:
 * -------
 * @Service
 * public class MyService {
 *
 *     @Autowired
 *     private MyRepository myRepository;
 *
 *     @Autowired
 *     private OtherService otherService;
 * }
 *
 * After:
 * ------
 * @Service
 * public class MyService {
 *
 *     private final MyRepository myRepository;
 *     private final OtherService otherService;
 *
 *     public MyService(MyRepository myRepository, OtherService otherService) {
 *         this.myRepository = myRepository;
 *         this.otherService = otherService;
 *     }
 * }
 */
@Value
@EqualsAndHashCode(callSuper = false)
public class FieldInjectionToConstructorInjectionRecipe extends Recipe {

    @Override
    public String getDisplayName() {
        return "Convert @Autowired field injection to constructor injection";
    }

    @Override
    public String getDescription() {
        return "Replaces Spring @Autowired field injection with constructor injection. " +
               "Marks injected fields as final, removes @Autowired annotations from fields, " +
               "and generates a constructor that initializes all formerly injected fields. " +
               "Skips classes that already have a constructor with parameters.";
    }

    @JsonCreator
    public FieldInjectionToConstructorInjectionRecipe() {
    }

    @Override
    public TreeVisitor<?, ExecutionContext> getVisitor() {
        return new FieldInjectionVisitor();
    }

    private static class FieldInjectionVisitor extends JavaIsoVisitor<ExecutionContext> {

        private static final String AUTOWIRED_FQN = "org.springframework.beans.factory.annotation.Autowired";
        private static final AnnotationMatcher AUTOWIRED_MATCHER = new AnnotationMatcher("@" + AUTOWIRED_FQN);

        @Override
        public J.ClassDeclaration visitClassDeclaration(J.ClassDeclaration classDecl, ExecutionContext ctx) {
            J.ClassDeclaration cd = super.visitClassDeclaration(classDecl, ctx);

            // Collect all @Autowired fields
            List<J.VariableDeclarations> autowiredFields = cd.getBody().getStatements().stream()
                    .filter(s -> s instanceof J.VariableDeclarations)
                    .map(s -> (J.VariableDeclarations) s)
                    .filter(this::hasAutowiredAnnotation)
                    .collect(Collectors.toList());

            // Nothing to do if no @Autowired fields
            if (autowiredFields.isEmpty()) {
                return cd;
            }

            // Skip if a parameterized constructor already exists (avoid conflicts)
            boolean hasParameterizedConstructor = cd.getBody().getStatements().stream()
                    .filter(s -> s instanceof J.MethodDeclaration)
                    .map(s -> (J.MethodDeclaration) s)
                    .anyMatch(m -> m.isConstructor() && !m.getParameters().isEmpty()
                                  && !(m.getParameters().size() == 1
                                       && m.getParameters().get(0) instanceof J.Empty));

            if (hasParameterizedConstructor) {
                return cd;
            }

            // Step 1 — Remove @Autowired from fields and make them final
            cd = cd.withBody(cd.getBody().withStatements(
                    ListUtils.map(cd.getBody().getStatements(), stmt -> {
                        if (!(stmt instanceof J.VariableDeclarations)) return stmt;
                        J.VariableDeclarations varDecl = (J.VariableDeclarations) stmt;
                        if (!hasAutowiredAnnotation(varDecl)) return stmt;

                        // Remove @Autowired annotation
                        varDecl = varDecl.withLeadingAnnotations(
                                varDecl.getLeadingAnnotations().stream()
                                        .filter(a -> !AUTOWIRED_MATCHER.matches(a))
                                        .collect(Collectors.toList())
                        );

                        // Add final modifier if not already present
                        if (varDecl.getModifiers().stream().noneMatch(m -> m.getType() == J.Modifier.Type.Final)) {
                            List<J.Modifier> modifiers = new ArrayList<>(varDecl.getModifiers());
                            modifiers.add(new J.Modifier(
                                    Tree.randomId(),
                                    Space.build(" ", Collections.emptyList()),
                                    Markers.EMPTY,
                                    null,
                                    J.Modifier.Type.Final,
                                    Collections.emptyList()
                            ));
                            varDecl = varDecl.withModifiers(modifiers);
                        }

                        return varDecl;
                    })
            ));

            // Step 2 — Build constructor source from collected fields
            String constructorParams = autowiredFields.stream()
                    .map(f -> {
                        String type = f.getType() != null ? f.getType().toString() : "Object";
                        // Use simple name from FQN if needed
                        if (type.contains(".")) {
                            type = type.substring(type.lastIndexOf('.') + 1);
                        }
                        String name = f.getVariables().get(0).getSimpleName();
                        return type + " " + name;
                    })
                    .collect(Collectors.joining(", "));

            String assignments = autowiredFields.stream()
                    .map(f -> "        this." + f.getVariables().get(0).getSimpleName()
                              + " = " + f.getVariables().get(0).getSimpleName() + ";")
                    .collect(Collectors.joining("\n"));

            String className = cd.getSimpleName();
            String constructorSource = "class " + className + " {\n" +
                    "    public " + className + "(" + constructorParams + ") {\n" +
                    assignments + "\n" +
                    "    }\n" +
                    "}";

            // Step 3 — Parse constructor and inject into class body
            J.ClassDeclaration templateClass = JavaTemplate.builder(constructorSource)
                    .build()
                    .apply(new Cursor(getCursor(), cd), cd.getBody().getCoordinates().lastStatement());

            // Extract the constructor from the template result and add to original class
            Optional<J.MethodDeclaration> newConstructor = templateClass.getBody().getStatements().stream()
                    .filter(s -> s instanceof J.MethodDeclaration)
                    .map(s -> (J.MethodDeclaration) s)
                    .filter(J.MethodDeclaration::isConstructor)
                    .findFirst();

            if (newConstructor.isPresent()) {
                List<Statement> newStatements = new ArrayList<>(cd.getBody().getStatements());
                // Insert constructor after fields, before other methods
                int insertIndex = (int) newStatements.stream()
                        .filter(s -> s instanceof J.VariableDeclarations)
                        .count();
                newStatements.add(insertIndex, newConstructor.get());
                cd = cd.withBody(cd.getBody().withStatements(newStatements));
            }

            // Step 4 — Remove unused @Autowired import
            maybeRemoveImport(AUTOWIRED_FQN);

            return cd;
        }

        private boolean hasAutowiredAnnotation(J.VariableDeclarations varDecl) {
            return varDecl.getLeadingAnnotations().stream()
                    .anyMatch(AUTOWIRED_MATCHER::matches);
        }
    }
}
